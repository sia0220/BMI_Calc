package com.example.bmi_calc;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class BMI_Activity extends AppCompatActivity {

    EditText edt_name,edt_wazn,edt_ghad;
    RadioButton rdo_man,rdo_women;
    Button btn_result;
    TextView txt_result;
    int vazn,ghadCM;
    float natije;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_bmi);

        edt_name = findViewById(R.id.edt_name);
        edt_wazn = findViewById(R.id.edt_wazn);
        edt_ghad = findViewById(R.id.edt_ghad);

        rdo_man = findViewById(R.id.rdo_man);
        rdo_women = findViewById(R.id.rdo_women);

        txt_result = findViewById(R.id.txt_result);
        btn_result = findViewById(R.id.btn_result);

        btn_result.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = edt_name.getText().toString().trim();
                String wazn = edt_wazn.getText().toString().trim();
                String ghad = edt_ghad.getText().toString().trim();

                if(TextUtils.isEmpty(name) || TextUtils.isEmpty(wazn) || TextUtils.isEmpty(ghad)){

                    Toast.makeText(BMI_Activity.this, "خونه ها رو پر کن دیگه", Toast.LENGTH_SHORT).show();
                }else {
                    vazn = Integer.parseInt((edt_wazn.getText().toString()));
                    ghadCM = Integer.parseInt((edt_ghad.getText().toString()));
                    float ghadM = (float) ghadCM/100;
                    ghadM = (float) Math.pow(ghadM,2);
                    natije = vazn/ghadM;

//                    int vaznM = (int)  (24*ghadM);
//                    int vaznMonaseb = vazn - vaznM;
//                    int vaznMonaseb2 = vaznM - vazn;

                    if (rdo_women.isChecked()){
                        natije--;
                    }

                    if(natije<18.5){
                        Toast.makeText(BMI_Activity.this, "وزنت کمه", Toast.LENGTH_SHORT).show();
                        txt_result.setText(name+" BMI تو شده"+natije);
                    } else if (natije>18.5 && natije<24.9) {
                        Toast.makeText(BMI_Activity.this, "وزنت رِواله داوش", Toast.LENGTH_SHORT).show();
                        txt_result.setText(name+" BMI تو شده"+natije);
                    } else if (natije>25) {
                        Toast.makeText(BMI_Activity.this, "دیگه داری میتِرِکی!", Toast.LENGTH_SHORT).show();
                        txt_result.setText(name+" BMI تو شده"+natije);
                        
                    }


                }

            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}